package com.cg.mobshop.ui;

import java.util.Scanner;

import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;
import com.cg.mobshop.util.Util;

public class MainUI {
	public static void main(String[] args) {
		int choice;
		Scanner scan = new Scanner(System.in);
		MobileService service = new MobileServiceImpl();

		// for (;;) {
		System.out.println("Welcome to Mobile Shopee");
		System.out.println("All Mobiles Record...");
		for (Integer m : Util.getMobileEntries().keySet()) {
			System.out.println("Mobile Id: " + m + " "
					+ Util.getMobileEntries().get(m));
		}
		System.out.println("Select the Mode of Operation");
		System.out.println("1. Sorting");
		System.out.println("2. Delete");
		System.out.println("3. Exit");
		choice = scan.nextInt();
		if (choice == 1) {
			System.out.println("Select the Sorting Criteria");
			System.out.println("1. Mobile Name");
			System.out.println("2. Mobile Price");
			System.out.println("3. Mobile Id");
			choice = scan.nextInt();
			// service.SortList(choice);

			if (choice == 1) {
				System.out.println(service.SortList(choice));
			} else if (choice == 2) {

			}
			// }
		} else if (choice == 2) {
			System.out.println("Enter your mobileId");
			choice = scan.nextInt();

		} else {
			System.out.println("You are exited ");
		}
	}
}
// }
