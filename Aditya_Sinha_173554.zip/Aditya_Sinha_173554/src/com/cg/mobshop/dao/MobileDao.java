package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileDao {
	public List<Mobiles> getMobilleList();

	public Mobiles deleteMobile(int mobcode);

	public List<Mobiles> SortList(int criteria);

}
