import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;
import com.cg.repo.ProductRepoImpl;

public class TestClient {

	
	@Test
	public void getProductRepo() {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("appCtx.xml");
		ProductRepo repo= (ProductRepo) context.getBean("repo");
		
		Product p1 = new Product();
		p1.setName("ball");
		p1.setPrice(50);
		
		repo.saveProduct(p1);
		
	}
}
