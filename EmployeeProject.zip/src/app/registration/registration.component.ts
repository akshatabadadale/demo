import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';
import { EmployeeModel } from '../model/employeemodel';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  
  employee: EmployeeModel;
  

  constructor(private empService: EmployeeService) { 
    this.employee = new EmployeeModel()
  }

  add(){
    this.empService.add(this.employee);
    this.employee = new EmployeeModel();
  }

}
