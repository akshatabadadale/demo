import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';
import { EmployeeModel } from '../model/employeemodel';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  employeeArr:EmployeeModel[];
  constructor(private empService:EmployeeService) {
    this.employeeArr = [];
   }

  ngOnInit() {
    this.employeeArr = this.empService.getEmployees();
  }

  delete(index: number) {
    this.empService.delete(index);
   }
}
