export class EmployeeModel{

    public employeeId:number;
    public employeeName:String;
    public employeeDepartment:String;
    public employeeSalary:number;
    public employeeGender:String;

}