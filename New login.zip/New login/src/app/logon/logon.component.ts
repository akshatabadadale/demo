import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import { TrustedString } from '@angular/core/src/sanitization/bypass';

@Component({
  selector: 'app-logon',
  templateUrl: './logon.component.html',
  styleUrls: ['./logon.component.css']
})
export class LogonComponent implements OnInit {



  constructor(private router: Router) { }
  hide = true;
  email = new FormControl('', [Validators.required, Validators.email]);
  inputEmail: string;
  password: string;

  ngOnInit() {
  }
  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }
  login(){
    console.log('login');
  }
}




