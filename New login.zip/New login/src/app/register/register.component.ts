import { registration } from "./../model/registration";
import { Component, OnInit, Input } from "@angular/core";
import { FormControl, Validators } from "@angular/forms";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  @Input() registration: registration;
  @Input() isEditing: boolean;

  constructor() {
    this.registration = new registration();
  }

  email = new FormControl("", [Validators.required, Validators.email]);
  inputEmail: string;

  ngOnInit() {}
  getErrorMessage() {
    return this.email.hasError('required')
      ? 'You must enter a value'
      : this.email.hasError('email')
      ? 'Not a valid email'
      : '';
  }
  validateboth() {
    if (this.registration.password === this.registration.repeatpassword) {
      alert('Password match');

    } else {
      alert('Password do not match');
      this.registration.password = '';
      this.registration.repeatpassword ='';
    }
  }
}
