
export class registration {
email: String;
password: String;
}
