package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class User {
	
	
	
	@FindBy(id="txtsequenceNumber")
	WebElement userId;
	
	@FindBy(id="txtsequenceNumber")
	WebElement userPass;
	
	@FindBy(id="txtsequenceNumber")
	WebElement authorizationType;

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(WebElement userId) {
		this.userId = userId;
	}

	public WebElement getUserPass() {
		return userPass;
	}

	public void setUserPass(WebElement userPass) {
		this.userPass = userPass;
	}

	public WebElement getAuthorizationType() {
		return authorizationType;
	}

	public void setAuthorizationType(WebElement authorizationType) {
		this.authorizationType = authorizationType;
	}
	
	
}
