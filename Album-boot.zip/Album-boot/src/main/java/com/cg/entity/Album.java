package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="album_info")
public class Album {
	
	@Id @Column(name="album_Ids")  @GeneratedValue
	private int albumId;
	@Column(length=20)
	private String albumName;
	private String albumArtist;
	private double albumPrice;
	
	public Album() {
		// TODO Auto-generated constructor stub
	}

	public int getAlbumId() {
		return albumId;
	}

	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}

	public String getAlbumName() {
		return albumName;
	}

	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}

	public String getAlbumArtist() {
		return albumArtist;
	}

	public void setAlbumArtist(String albumArtist) {
		this.albumArtist = albumArtist;
	}

	public double getAlbumPrice() {
		return albumPrice;
	}

	public void setAlbumPrice(double albumPrice) {
		this.albumPrice = albumPrice;
	}

	@Override
	public String toString() {
		return "AlbumEntity [albumId=" + albumId + ", albumName=" + albumName + ", albumArtist=" + albumArtist
				+ ", albumPrice=" + albumPrice + "]";
	}

	public Album(int albumId, String albumName, String albumArtist, double albumPrice) {
		super();
		this.albumId = albumId;
		this.albumName = albumName;
		this.albumArtist = albumArtist;
		this.albumPrice = albumPrice;
	}
	
	
}
