package com.cg.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Album;
import com.cg.repo.AlbumRepo;
@Repository
@Transactional
public class AlbumServiceImpl implements AlbumService{

	@Autowired
	private AlbumRepo repo;
	
	@Override
	public void saveAlbum(Album a) {
		repo.save(a);
	}

	@Override
	public Album get(int albumId) {
		return repo.findById(albumId).get();
	}

	public Iterable<Album> getAll() {
		return repo.findAll();
	}
	@Override
	public String deleteAlbum(int albumId) {
		Album a1 = repo.findById(albumId).get();
		repo.delete(a1);
		return "Deleted Successfully"; 
				
	}

	@Override
	public Album updateAlbum(Album a, int albumId) {
		a.setAlbumId(albumId);
		repo.save(a);
		return a;
	}

	@Override
	public Album findByAlbumName(String name) {
		return repo.findByAlbumName(name);
	}
	
	public Album getAlbums(int albumId) throws NoSuchElementException {
		try {
			return repo.findById(albumId).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("NO AlBUM RECORDS FOUND FOR ID "+ albumId );
			
		}
		
		
	}

}
