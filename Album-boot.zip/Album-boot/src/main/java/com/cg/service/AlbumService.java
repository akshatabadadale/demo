package com.cg.service;

import com.cg.entity.Album;


public interface AlbumService {
	 
	void saveAlbum(Album a);
	
	Album get(int albumId);
	
	Iterable<Album> getAll();
	
	public String deleteAlbum(int albumId);
	
	public Album updateAlbum(Album a, int albumId);
	
	Album findByAlbumName(String name);
	
}
